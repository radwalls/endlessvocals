RDWS RAW SYNTH V2
=================

RDWS RAW SYNTH V2 is a 12-voice stereo software instrument built around a
photographed-hardware interface. Every one of its 33 rotary controls turns
around the original control's measured pivot point.

Sound engine
------------

- Two oscillators per voice: sine, saw, pulse and triangle
- Waveform-aware Shape controls, independent tuning and broadband noise
- Resonant low-pass filter with drive and bipolar envelope modulation
- Separate amplifier and filter ADSR envelopes
- Pitch LFO, analog drift, portamento and pitch-wheel support
- True stereo voice spread
- Stereo chorus, crossfeed delay and reverb
- Soft saturation and output metering
- 35 host-automatable parameters

Presets
-------

Raw Arrival, Glass Engines, Basement Mono, Orbit Choir, Rust Pluck and Wide
Awake are complete parameter programs and are saved with your DAW session.

Formats
-------

- Audio Unit instrument for Logic Pro and other AU hosts
- VST3 instrument
- Standalone application
- Version 2.0.0

Support: Radwalls@gmail.com

