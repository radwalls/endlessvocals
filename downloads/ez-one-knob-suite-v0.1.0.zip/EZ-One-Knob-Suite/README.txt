RAD WALLS x ENDLESS VOCALS
EZ ONE-KNOB PLUG-IN SUITE 0.1.0

INCLUDED
EZ Verb, EZ Delay, EZ Doubler, EZ Chorus, EZ Pressor, EZ D-esser,
EZ Q, EZ Sat, and EZ Tone.

REQUIREMENTS
Apple Silicon Mac, macOS 13 or newer, and Logic Pro or another host that
supports Audio Units.

INSTALL
1. Quit Logic Pro.
2. Copy all nine .component files into:
   ~/Library/Audio/Plug-Ins/Components/
3. Reopen Logic Pro.
4. If they do not appear, open Logic Pro > Settings > Plug-in Manager,
   locate "Rad Walls Audio," and choose Reset & Rescan Selection.

USE
Add a plug-in to an Audio FX slot. Turn the main control toward MORE until
the track feels right. Use BYPASS to compare the processed and original sound.

SUPPORT
radwalls@gmail.com
https://endlessvocals.com/

This purchase is for one person. Please do not redistribute the plug-ins or
the download link.
